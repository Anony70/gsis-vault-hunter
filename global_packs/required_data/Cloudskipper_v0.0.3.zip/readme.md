# Cloudskipper
Majestic, bird-like elementals capable of skipping on air itself.

[+] **Skipping on Clouds**
By jumping midair, you can create clouds to skip on them, allowing you to jump an infinite number of times before landing.
[Info]: This can't be used at 3 food shanks or lower, and exhausts you with each use.
Cloudskipping pushes nearby mobs.

[+] **Raincloud**
While sneaking midair, you create a rain cloud below you, causing you to hover in place, unable to move or fall. This can't be used at 3 food shanks or lower, and is heavily exhausting.

[+] **Slow Falling**
You fall to the ground as light as rainfall, preventing you from taking fall damage.

[+] **Air Affinity**
You may break blocks in the air as others do on land.

[-] **Dissipation**
After you take damage, your Cloudskipping, and Raincloud is disabled temporarily.

[-] **Cloudy Feet**
Your feet are not made for walking. When on the ground, your movement is slippery, and you move 60% slower.

[-] **Incompatible Biology**
Your biology does not allow you to safely or properly use Elytra, so it will not activate when worn.

# Changelog
- Fixed bug rarely caused by lag on some modded servers